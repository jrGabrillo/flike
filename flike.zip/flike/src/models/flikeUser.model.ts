export class FlikeUser {
    constructor(
        public id:string,
        public firstname: string,
        public fullname:string,
        public lastname:string,
        public typeOfUser: string,
        public email: string,
        public optIns: any,
        public legalStatement:string
    ){

    }
}